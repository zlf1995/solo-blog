title: ionic3 Barcodescanner 安卓扫码界面返回两次
date: '2019-09-25 01:30:58'
updated: '2019-09-25 01:30:58'
tags: [ionic3]
permalink: /articles/2019/09/25/1569346258212.html
---
![](https://img.hacpai.com/bing/20190403.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

关于 cordova-plugin-barcodescanner 的问题，暂时没有找到什么好的解决方案，只能全局设置一个变量，来记录相机的打开状态。
